var mongoose = require('mongoose');
var Emp = mongoose.model('Emp', { empno:Number, ename: String,salary:Number });
function insert(empno, ename,salary){
  mongoose.connect('mongodb://localhost:27017/mydb');
  var empobj = new Emp();
  empobj.empno = empno;
  empobj.ename = ename;
  empobj.salary = salary;
  console.log(empobj);
  empobj.save((err,e)=>{
      mongoose.disconnect();
      if(err) console.log("Error in insertion");
      if(e) console.log("Inserted successfully " + e._id);
});
}
function list(req,res,fn){
  console.log(res);
  
  mongoose.connect('mongodb://localhost:27017/mydb',{ useNewUrlParser: true });
  Emp.find((err,arr)=>{
          mongoose.disconnect();
     if(err) console.log("Error in Retrival");
     if (arr){
         //console.log(arr);
      /*   var str = "<table border='1'>"
         for(var i = 0;i<arr.length;i++){
            str+="<tr><td>"+arr[i].empno+"</td>"
            str+="<td>"+arr[i].ename+"</td>"
            str+="<td>"+arr[i].salary+"</td></tr>"
         }
         str+= "</table>";
         console.log(str); */
         
         res.end(JSON.stringify(arr));
     }
  });
} 
      
exports.insert = insert;
exports.list = list;
