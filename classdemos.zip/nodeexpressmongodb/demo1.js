var http = require('http');
var express = require('express');
var bodyparser=require('body-parser');
var path=require('path');

var app = express();
var empmgr = require('./empmgr');
app.use(bodyparser.urlencoded({ extended: false }));
 
 app.get("/",(req,resp)=>{
  resp.sendFile(path.join(__dirname,"demo1.html"));
});
app.post("/add",(req,resp)=>{
  console.log(req.body);
   empmgr.insert(parseInt(req.body.empno),req.body.ename, parseInt(req.body.salary));
    resp.end("Inserted ...   ");
});
app.get("/list",(req,resp)=>{
  resp.setHeader('Access-Control-Allow-Origin', 'http://localhost:3000');
  empmgr.list(req,resp);
});


var server = http.createServer(app);
server.on("listening",()=>{console.log("started  Listening on port 80")});
server.listen(80);
