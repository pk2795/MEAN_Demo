function init(app){
    var path=require('path');
//var path="\\siemensdemos\\expressdemo1/statics/";
//var path="c:\\siemensdemos\\expressdemo1/statics/";
app.get("/",(req,resp)=>{
  resp.sendFile(path.join(__dirname,"statics","index.html"));
});
app.get("/nagios.png",(req,resp)=>{
  
  resp.sendFile(path.join(__dirname,"statics","nagios.png"));
});
app.get("/scan.pdf",(req,resp)=>{
  resp.sendFile(path.join(__dirname,"statics","scan.pdf"));
});
app.get("/t1.html",(req,resp)=>{
     resp.sendFile(path.join(__dirname,"statics","t1.html"));
});
app.get("/t2.html",(req,resp)=>{
     resp.sendFile(path.join(__dirname,"statics","t2.html"));
});
app.get("/*",(req,resp)=>{
     resp.write("Check URL Once ....");
     resp.end();
});
}
exports.init = init;