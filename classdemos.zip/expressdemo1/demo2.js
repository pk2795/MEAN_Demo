var http = require('http');
var express = require('express');

var app = express();
var code = require('./demo2helper');
code.init(app);
var server = http.createServer(app);
server.on("listening",()=>{console.log("started  Listening on port 80")});
server.listen(80);
