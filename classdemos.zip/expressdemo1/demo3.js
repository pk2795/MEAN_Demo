var http = require('http');
var express = require('express');
 var path=require('path');
var app = express();
 app.get("/",(req,resp)=>{
  resp.sendFile(path.join(__dirname,"statics","demo3.html"));
});
app.get("/add/:n1/:n2",(req,resp)=>{
    var sum = parseInt(req.params.n1) + parseInt(req.params.n2);
     resp.end("Sum  = , "+ sum);
});
app.get("/hello/:nm",(req,resp)=>{
     resp.end("Hello, "+ req.params.nm);
});

app.get("/t2.html",(req,resp)=>{
     resp.sendFile(path.join(__dirname,"statics","t2.html"));
});

var code = require('./demo2helper');
code.init(app);
var server = http.createServer(app);
server.on("listening",()=>{console.log("started  Listening on port 80")});
server.listen(80);
