var http = require('http');
var express = require('express');
var bodyparser=require('body-parser');
var path=require('path');
var app = express();
app.use(bodyparser.urlencoded({ extended: false }));
 app.get("/",(req,resp)=>{

  resp.sendFile(path.join(__dirname,"statics","demo5.html"));
});
app.post("/add",(req,resp)=>{
  console.log(req);
  console.log(req.body);
    var sum = parseInt(req.body.n1) + parseInt(req.body.n2);
     resp.end("Sum  =  "+ sum);
});
app.post("/hello",(req,resp)=>{
     resp.end("Hello, "+ req.body.nm);
});


var code = require('./demo2helper');
code.init(app);
var server = http.createServer(app);
server.on("listening",()=>{console.log("started  Listening on port 80")});
server.listen(80);
