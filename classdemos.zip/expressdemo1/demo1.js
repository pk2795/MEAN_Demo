var http = require('http');
var express = require('express');
var app = express();
app.get("/",(req,resp)=>{
    resp.sendfile("t1.html");
    resp.end("<h1><a href='t1.html'>t1.html</a><br/><a href='t2.html'>t2.html</a></h1>");
    
})
app.get("/t1.html",(req,resp)=>{
     resp.end("<h1>In t1 .html </h1>");
});
app.get("/t2.html",(req,resp)=>{
     resp.end("<h1>In t2 .html </h1>");
});
var server = http.createServer(app);
server.on("listening",()=>{console.log("started  Listening on port 80")});
server.listen(80);
