var http = require('http');
var express = require('express');
 var path=require('path');
var app = express();
 app.get("/",(req,resp)=>{
  resp.sendFile(path.join(__dirname,"statics","demo4.html"));
});
app.get("/add",(req,resp)=>{
    var sum = parseInt(req.query.n1) + parseInt(req.query.n2);
     resp.end("Sum  =  "+ sum);
});
app.get("/hello",(req,resp)=>{
     resp.end("Hello, "+ req.query.nm);
});


var code = require('./demo2helper');
code.init(app);
var server = http.createServer(app);
server.on("listening",()=>{console.log("started  Listening on port 80")});
server.listen(80);
