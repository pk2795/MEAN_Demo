console.log(process.pid)

var v1 = "Abc";
console.log(v1);
check();
function check(){
	console.log("check invoked ");

}