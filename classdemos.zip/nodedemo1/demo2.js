var v = require('./t1');
// option1 - search t1.js in current folder
//option 2 - search for t1/index.js
v.add(10,10);
console.log("in demo2.js ...");
var v1 = require('./t1');
console.log("after second required...");
console.log(v.add(10,10));