console.log("in t1.js");
var v1var ="v1 var in t1 index.js";
v1 ="v1  in t1 index.js";

function add(i,j){
    console.log("in t1.js - add function ...");
    return i+j;
}
function print (){
    console.log("v1var = " + v1var);
    console.log("v1 = " + v1 );
}
exports.add=add;
exports.print=print;