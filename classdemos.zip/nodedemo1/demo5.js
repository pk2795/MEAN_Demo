var http = require('http');
var totalrequests = 0;
var currentrequest = 0;
var server = http.createServer((req,resp)=>{
    req.on("end",()=>{console.log("end of request")});
    
    console.log(req.url + ", " + req.method);
    if(req.url=="/" )
        resp.write("<h1><a href='t1.html'>t1.html</a><br/><a href='t2.html'>t2.html</a></h1>");
    if(req.url=="/t1.html" )
        resp.write("<h1>In t1 .html </h1>");
    if(req.url=="/t2.html" )
        resp.write("<h1>In t2 .html </h1>");
    resp.end("<h1>Hello World </h1>");
     currentrequest--;
});
server.on("listening",()=>{console.log("started  Listening on port 80")});
server.listen(80);
