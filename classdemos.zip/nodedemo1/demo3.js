var t1 = require('./t1');
t1.print();
var v1var ="v1 var in demo3";
v1 ="v1  in demo3.js";
console.log("v1 var = " + v1var);
console.log("v1 = " + v1);
t1.print();
console.log("v1 var = " + v1var);
console.log("v1 = " + v1);