var http = require('http');
var totalrequests = 0;
var currentrequest = 0;
var server = http.createServer((req,resp)=>{
    totalrequests++;
    currentrequest++;
    var str = " Total Requests so far = " + totalrequests + "<br/>";
     str+= " Current requests = " + currentrequest;
    console.log(str);
    resp.write("<h1>" + str + "</h1>");
    resp.end("<h1>Hello World </h1>");
     currentrequest--;
});
server.listen(80);
