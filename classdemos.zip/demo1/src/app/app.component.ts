import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `   <my-app1>Second app</my-app1>
  <h1>Hello {{name}}</h1>
  <input type="button" value="Click" (click)="m1()" />
  <img [src]="imgname"/>
  `,
})
export class AppComponent  { 
  name:string = 'Siemens';
  imgname:string="nagios.png";
  public m1():void{
    console.log("in m1");
    if (this.imgname==="nagios.png")
      this.imgname="nagios1.png";
    else
      this.imgname="nagios.png";
  }
 }
