import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './base.html',
  styleUrls:['./base.css']
})
export class AppComponent  { name = 'Angular'; }
