"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var App1Component = (function () {
    function App1Component() {
        this.uname = "Vaishali";
    }
    return App1Component;
}());
App1Component = __decorate([
    core_1.Component({
        selector: 'my-app1',
        template: "\n  Name : <input type=\"text\" [(ngModel)]=\"uname\"  value=\"a\" /><br/>\n  Name : <input type=\"text\" [(ngModel)]=\"uname\"  value=\"a\" /><br/>\n  Name : <input type=\"text\" [(ngModel)]=\"uname\"  value=\"a\" /><br/>\n  Name : <input type=\"text\" [(ngModel)]=\"uname\"  value=\"a\" /><br/>\n  \n  <h1>Hello, {{uname}}</h1>",
    })
], App1Component);
exports.App1Component = App1Component;
//# sourceMappingURL=app1.component.js.map