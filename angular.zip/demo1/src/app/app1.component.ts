import { Component } from '@angular/core';

@Component({
  selector: 'my-app1',
  template: `
  Name : <input type="text" [(ngModel)]="uname"  value="a" /><br/>
  Name : <input type="text" [(ngModel)]="uname"  value="a" /><br/>
  Name : <input type="text" [(ngModel)]="uname"  value="a" /><br/>
  Name : <input type="text" [(ngModel)]="uname"  value="a" /><br/>
  
  <h1>Hello, {{uname}}</h1>`,
})
export class App1Component  { 
  uname:string="Vaishali";
 }
