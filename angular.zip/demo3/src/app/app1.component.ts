import { Component } from '@angular/core';
import {SimpleService} from './simple.service';
import {Http, Response} from '@angular/http';
@Component({
  selector: 'my-app1',
  templateUrl: './app1.html'
 
})
export class App1Component  { name = 'App1Angular'; 
obj:Object;
constructor(private ss:SimpleService){
  }
getuser(){
  console.log("getUser");
  this.ss.getUser(3).subscribe
 (
   (resp:Response)=>this.obj = resp["data"],
   (obj:any)=>console.log("errrorrr")
 )
}
}
