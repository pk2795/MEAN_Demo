import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpModule} from '@angular/http';
import { AppComponent }  from './app.component';

import { App1Component }  from './app1.component';
import {SimpleService} from './simple.service';
@NgModule({
  imports:      [ BrowserModule, HttpModule ],
  declarations: [ AppComponent,App1Component ],
  bootstrap:    [ AppComponent ,App1Component],
  providers: [SimpleService]
})
export class AppModule { }
