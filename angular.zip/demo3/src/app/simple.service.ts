import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Observable} from 'rxjs/Observable'
import  'rxjs/add/operator/map';
@Injectable()
export class SimpleService
{
    constructor(private http:Http){
        console.log("Simple Service Constructor ");
    }

    getUser(usrid:number):Observable<Response>
    {
        let url:string="https://reqres.in/api/users/" + usrid;
         return    this.http.get(url).map((resp:Response)=>resp.json());
 
    }
}