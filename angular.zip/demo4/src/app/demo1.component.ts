import { Component } from '@angular/core';

@Component({
  
  template: '<h1>In Demo1 Coponent UI {{name}}</h1>',
  
})
export class Demo1Component  { name = 'Angular'; }
