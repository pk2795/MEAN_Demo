import { Component } from '@angular/core';

@Component({
  
  template: '<h1>In Demo2 Coponent UI {{name}}</h1>',
  
})
export class Demo2Component  { name = 'Second COmp'; }
