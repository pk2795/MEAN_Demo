import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{RouterModule} from '@angular/router';
import {Demo1Component} from './demo1.component';
import {Demo2Component} from './demo2.component';
import { AppComponent }  from './app.component';

@NgModule({

  imports:      [ BrowserModule,
    RouterModule.forRoot([
      { path:"demo1", component:Demo1Component },
      { path:"demo2", component:Demo2Component }
      ],{useHash:true})],
  declarations: [ AppComponent ,Demo1Component,Demo2Component],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
