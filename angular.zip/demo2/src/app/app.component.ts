import { Component } from '@angular/core';
import {Emp} from './Emp';
@Component({
  selector: 'my-app',
  templateUrl: '/static/app.html'
})
export class AppComponent  { 
  emp:Emp = new Emp();
  emparr:Array<Emp> = new Array();
  constructor(){
    this.emparr.push({ "empno": 1, "ename": "AAA", "salary": 1000 });
    this.emparr.push({ "empno": 2, "ename": "BBB", "salary": 2000 });
  }
public add() : void{
  this.emparr.push(this.emp);
  this.emp = new Emp();
  console.log(this.emparr);
}
public delete(index:number):void{
  this.emparr.splice(index,1);
}
}
